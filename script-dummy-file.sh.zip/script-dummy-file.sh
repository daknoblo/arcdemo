#!/bin/bash

# Create a file named dummy-file.check in /home/root
mkdir -p /home/root
touch /home/root/dummy-file.check
